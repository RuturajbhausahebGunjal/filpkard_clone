import 'package:carousel_slider/carousel_slider.dart';
import 'package:filpkart/OTPpage.dart';
import 'package:filpkart/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomFlipcard extends StatelessWidget {
  final String title1;
  final String subtitle1;
  final String subtitle2;
  final double fontSize;

  const CustomFlipcard({
    super.key,
    required this.title1,
    required this.subtitle1,
    required this.fontSize,
    required this.subtitle2,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title1,
            style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w400),
          ),
          Text.rich(TextSpan(children: [
            TextSpan(text: subtitle1, style: TextStyle(fontSize: 15.sp)),
            TextSpan(text: subtitle2, style: TextStyle(fontSize: 15.sp))
          ]))
        ],
      ),
    );
  }
}

class Custombtn extends StatelessWidget {
  final dynamic fontSize;
  final String text;

  const Custombtn({
    super.key,
    required this.text,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: () {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => OtpPage(),
            ));
      },
      // color: Color.fromARGB(255, 9, 48, 240),
      child: Row(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 7.w),
            child: Icon(
              Icons.account_circle_outlined,
              color: Colors.white,
              size: 23.sp,
            ),
          ),
          Text(
            'Login',
            style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }
}

class CustomTextfiled extends StatelessWidget {
  final String hintText;
  final dynamic prefixIcon;
  final dynamic color;
  const CustomTextfiled(
      {super.key, required this.hintText, this.prefixIcon, this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 47,
      child: TextField(
        decoration: InputDecoration(
          fillColor: Color.fromARGB(255, 238, 232, 232),
          filled: true,
          prefixIcon: prefixIcon,
          hintText: hintText,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}

class CustomSizebox extends StatelessWidget {
  final double? height;
  final double? width;
  const CustomSizebox({super.key, this.height, this.width});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
    );
  }
}

class Products extends StatelessWidget {
  final dynamic Images;
  final String? text;
  final double? height;
  const Products({super.key, required this.Images, this.text, this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
            child: Image.asset(
              Images,
              height: 60,
            ),
          ),
          Text(
            text!,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
          )
        ],
      ),
    );
  }
}

class CustomCarousel extends StatelessWidget {
  const CustomCarousel({super.key});

  @override
  Widget build(BuildContext context) {
    return CarouselSlider.builder(
        itemCount: 4,
        itemBuilder: (context, index, realIndex) {
          return Container(
            child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset(images[index])),
          );
        },
        options: CarouselOptions(
            height: 140,
            autoPlay: true,
            autoPlayCurve: Curves.fastOutSlowIn,
            autoPlayAnimationDuration: Duration(milliseconds: 400)));
  }
}

class CustomSkincare extends StatelessWidget {
  final double? height;
  final double? height2;
  final double? width;
  final dynamic color;
  final dynamic image;
  final String text1;
  final String text2;
  const CustomSkincare(
      {super.key,
      this.height,
      this.height2,
      this.color,
      this.image,
      this.width,
      required this.text1,
      required this.text2});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Container(
          height: height,
          decoration: BoxDecoration(
              color: Color.fromARGB(255, 225, 216, 216),
              borderRadius: BorderRadius.circular(5)),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(4),
                child: ClipRRect(
                  child: Image.asset(
                    'product4.jpeg',
                    height: height2,
                    width: width,
                    fit: BoxFit.cover,
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              Text(
                text1,
                style: TextStyle(fontSize: 11.sp),
              ),
              Text(
                text2,
                style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.bold),
              )
            ],
          ),
        ),
        Container(
          height: height,
          decoration: BoxDecoration(
              color: Color.fromARGB(255, 225, 216, 216),
              borderRadius: BorderRadius.circular(5)),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(4),
                child: ClipRRect(
                  child: Image.asset(
                    'product3.jpeg',
                    height: height2,
                    width: width,
                    fit: BoxFit.cover,
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              Text(
                text1,
                style: TextStyle(fontSize: 11.sp),
              ),
              Text(
                text2,
                style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.bold),
              )
            ],
          ),
        ),
        Container(
          height: height,
          decoration: BoxDecoration(
              color: Color.fromARGB(255, 225, 216, 216),
              borderRadius: BorderRadius.circular(5)),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(4),
                child: ClipRRect(
                  child: Image.asset(
                    'product2.jpeg',
                    height: height2,
                    width: width,
                    fit: BoxFit.cover,
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              Text(
                text1,
                style: TextStyle(fontSize: 11.sp),
              ),
              Text(
                text2,
                style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.bold),
              )
            ],
          ),
        )
      ],
    );
  }
}

class CustomProducts extends StatelessWidget {
  final double height;
  final double? width;
  final dynamic Color1;
  final dynamic Color2;
  final dynamic image;
  final dynamic press;
  const CustomProducts(
      {super.key,
      required this.height,
      this.width,
      this.Color1,
      this.Color2,
      this.image,
      this.press});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: Container(
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color1,
        ),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 5,
              mainAxisSpacing: 5,
              mainAxisExtent: 180),
          itemCount: someproducts.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(5),
              child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8), color: Color2),
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Center(
                          child: ClipRRect(
                            child: Image.asset(
                              someproducts[index],
                              height: 130,
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Center(
                          child: Text(
                            headingnames[index],
                            style: TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

List someproducts = [
  'goggles.jpeg',
  'shoes.jpeg',
  'watch.jpeg',
  'bags.jpeg',
  'men-clothing.jpeg',
  'night-out.jpeg'
];

List headingnames = [
  " Men's accessories ",
  "Mens, sport shoes",
  "Mens, sport shoes",
  "Mens, sport shoes",
  "Mens, sport shoes",
  "Mens, sport shoes",
];

class CustomNavbar extends StatelessWidget {
  final dynamic Iconbtn1;
  final dynamic Iconbtn2;
  final dynamic image;
  final String text1;
  final double height;
  const CustomNavbar(
      {super.key,
      this.Iconbtn1,
      this.image,
      required this.text1,
      required this.height,
      this.Iconbtn2});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(Icons.arrow_back)),
        Padding(
          padding: const EdgeInsets.all(5),
          child: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset(
              image,
              height: height,
            ),
          ),
        ),
        CustomSizebox(
          width: 100.h,
        ),
        IconButton(onPressed: () {}, icon: Iconbtn1),
        IconButton(onPressed: () {}, icon: Iconbtn2),
        CustomSizebox(
          width: 10.h,
        ),
        Text(
          text1,
          style: TextStyle(fontSize: 18),
        )
      ],
    );
  }
}

class customItem extends StatelessWidget {
  final dynamic images;
  final double height;
  final dynamic Iconbtn1;
  final dynamic Iconbtn2;
  const customItem(
      {super.key,
      this.images,
      required this.height,
      this.Iconbtn1,
      this.Iconbtn2});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Image(
          image: images,
          height: height,
        ),
        CustomSizebox(
          width: 50.h,
        ),
        Column(
          children: [
            IconButton(onPressed: () {}, icon: Iconbtn1),
            CustomSizebox(
              height: 50.h,
            ),
            IconButton(onPressed: () {}, icon: Iconbtn2)
          ],
        ),
      ],
    );
  }
}

class CustomText extends StatelessWidget {
  final String text1;

  final dynamic Icons;
  final dynamic colors;
  const CustomText({
    super.key,
    required this.text1,
    this.Icons,
    this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Container(
          child: Padding(
            padding: const EdgeInsets.all(3),
            child: Icon(
              Icons,
              color: colors,
              size: 20,
            ),
          ),
          decoration: BoxDecoration(
              color: const Color.fromARGB(255, 172, 240, 207),
              borderRadius: BorderRadius.circular(20)),
        ),
        Text(
          text1,
          style: TextStyle(fontSize: 14),
        )
      ],
    );
  }
}

class Customtext1 extends StatelessWidget {
  final String text1;
  final String text2;
  final double? fontsize;
  final dynamic fontwight;
  final dynamic color;
  const Customtext1({
    super.key,
    required this.text1,
    required this.text2,
    this.fontsize,
    this.fontwight,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          text1,
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 17),
        ),
        Text(
          text2,
          style: TextStyle(fontSize: 15),
        )
      ],
    );
  }
}

class CustomRating extends StatelessWidget {
  final String text1;
  final String text2;

  const CustomRating({
    super.key,
    required this.text1,
    required this.text2,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        RatingBar.builder(
          initialRating: 3,
          itemBuilder: (context, index) => Icon(
            Icons.star,
            color: Colors.amberAccent,
          ),
          itemCount: 5,
          itemSize: 16,
          allowHalfRating: true,
          itemPadding: EdgeInsets.symmetric(horizontal: 3),
          onRatingUpdate: (rating) {
            print(rating);
          },
        ),
        CustomSizebox(
          width: 10.w,
        ),
        Text(
          text1,
          style: TextStyle(
              fontSize: 16,
              color: Colors.blueAccent,
              fontWeight: FontWeight.w500),
        ),
        Text(
          text2,
          style:
              TextStyle(fontSize: 14, color: Color.fromARGB(255, 10, 76, 190)),
        )
      ],
    );
  }
}

class CustomStack extends StatelessWidget {
  final double height;
  final double width;
  final String text1;
  final dynamic color;
  const CustomStack(
      {super.key,
      required this.height,
      required this.width,
      required this.text1,
      this.color});

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Transform(
          child: Container(
            height: height,
            width: width,
            color: color,
          ),
          alignment: FractionalOffset.center,
          transform: Matrix4.identity()..rotateZ(10 * 3.0315927 / 180)),
      Transform(
          child: Container(
            height: 40,
            width: 80,
            color: Color.fromARGB(255, 77, 238, 157),
            child: Center(
                child: Text(
              text1,
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.white),
            )),
          ),
          alignment: FractionalOffset.center,
          transform: Matrix4.identity()..rotateZ(0 * 3.0315927 / 180)),
    ]);
  }
}
