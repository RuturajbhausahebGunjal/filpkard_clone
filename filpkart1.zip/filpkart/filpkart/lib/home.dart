import 'package:carousel_slider/carousel_slider.dart';
import 'package:filpkart/OTPpage.dart';
import 'package:filpkart/custom.dart';
import 'package:filpkart/details.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

List<String> products = [
  'Mobiles.jpg',
  'fashions.jpg',
  'Electronics.jpg',
  'furnitures.jpg',
  'Toys.jpg'
];

List<String> productname = [
  'Mobiles',
  'fashions',
  'Electronics',
  'furnitures',
  'Toys & More'
];

List images = ['bigbazzar.jpg', 'images.jpg', 'projector.jpg', 'laptop.jpg'];

int activeIndex = 0;

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        title: CustomFlipcard(
          title1: 'Flipcard',
          fontSize: 20,
          subtitle1: 'Expolre',
          subtitle2: 'Plus',
        ),
        actions: [
          Icon(
            Icons.phone_android_sharp,
            size: 23.sp,
          ),
          Custombtn(
            text: 'Login',
            fontSize: 15,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 7.w),
            child: Icon(
              Icons.shopping_cart_outlined,
              size: 23.sp,
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: [
              CustomTextfiled(
                  color: Color.fromARGB(255, 220, 218, 218),
                  prefixIcon: Icon(Icons.search_rounded),
                  hintText: 'Search for Products, Brands and More'),
              CustomSizebox(height: 20),
              CustomSizebox(
                height: 10,
              ),
              Container(
                height: 100,
                child: ListView.builder(
                  itemCount: products.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return Products(
                      Images: products[index],
                      text: productname[index],
                    );
                  },
                ),
              ),
              CustomSizebox(
                height: 20,
              ),
              Stack(alignment: Alignment.bottomCenter, children: [
                CarouselSlider.builder(
                    itemCount: 4,
                    itemBuilder: (context, index, realIndex) {
                      return Container(
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Image.asset(images[index])),
                      );
                    },
                    options: CarouselOptions(
                      height: 140,
                      autoPlay: true,
                      autoPlayCurve: Curves.fastOutSlowIn,
                      onPageChanged: (index, reason) {
                        setState(() {
                          activeIndex = index;
                        });
                      },
                      autoPlayAnimationDuration: Duration(
                        milliseconds: 400,
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: AnimatedSmoothIndicator(
                    activeIndex: activeIndex,
                    count: images.length,
                    effect: WormEffect(
                        dotHeight: 6,
                        dotWidth: 10,
                        dotColor: Color.fromARGB(255, 157, 151, 159),
                        activeDotColor: Colors.white),
                  ),
                )
              ]),
              CustomSizebox(
                height: 20.h,
              ),
              CustomSkincare(
                  height: 125.h,
                  color: Color.fromARGB(255, 204, 194, 194),
                  height2: 70.h,
                  width: 90.w,
                  text1: 'Get Glowing Skin',
                  text2: 'Up to 60% off'),
              CustomSizebox(
                height: 10.h,
              ),

              CustomProducts(
                height: 550,
                Color1: Color.fromARGB(255, 236, 234, 237),
                Color2: Color.fromARGB(255, 167, 164, 164),
                press: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Details(),
                    )),
              ),

              // CustomSizebox(
              //   height: 10.h,
              // ),
              // Container(
              //   height: 300,
              //   color: Colors.amberAccent,
              // )
            ],
          ),
        ),
      ),
      drawer: Drawer(
          child: ListView(
        children: [
          Container(
            height: 50.h,
            color: Color.fromARGB(255, 42, 119, 252),
            child: Row(
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  child: Icon(Icons.person, color: Colors.white),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => OtpPage()));
                  },
                  child: Text(
                    "Login & SignUp",
                    style: TextStyle(
                        fontSize: 16.sp,
                        color: Colors.white,
                        fontWeight: FontWeight.w600),
                  ),
                ),
                CustomSizebox(
                  width: 80.h,
                ),
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: Image.asset(
                    "flipkard-logo.png",
                    height: 25.h,
                  ),
                )
              ],
            ),
          ),
          ListTile(
            title: Text("SuperCoin Zone"),
            leading: Icon(
              Icons.offline_bolt_outlined,
              size: 17,
            ),
          ),
          ListTile(
            title: Text("FlipKard plus Zone"),
            leading: Icon(
              Icons.double_arrow_rounded,
              size: 17,
            ),
          ),
          Divider(
            height: 2,
            indent: 2,
            endIndent: 2,
          ),
          ListTile(
            title: Text("All Categories"),
            leading: Icon(
              Icons.apps_rounded,
              size: 17,
            ),
          ),
          ListTile(
            title: Text("More on FilpKard"),
            leading: Icon(
              Icons.dashboard_rounded,
              size: 17,
            ),
          ),
        ],
      )),
    );
  }
}
