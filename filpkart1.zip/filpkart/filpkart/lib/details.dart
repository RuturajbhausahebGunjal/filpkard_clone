import 'package:filpkart/custom.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

class Details extends StatefulWidget {
  const Details({super.key});

  @override
  State<Details> createState() => _DetailsState();
}

double value = 3.5;

class _DetailsState extends State<Details> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          children: [
            CustomNavbar(
              text1: 'Login',
              image: 'flipkard-logo.png',
              height: 25.h,
              Iconbtn1: Icon(Icons.search),
              Iconbtn2: Icon(Icons.shopping_cart_outlined),
            ),
            CustomSizebox(
              height: 30.h,
            ),
            customItem(
              images: AssetImage("goggles.jpeg"),
              height: 160,
              Iconbtn1: Icon(Icons.favorite_border),
              Iconbtn2: Icon(Icons.screen_share_rounded),
            ),
            CustomSizebox(
              height: 30.h,
            ),
            CustomText(
              text1: '89 peoples ordered this in the last 30 days',
              Icons: Icons.trending_up,
              colors: const Color.fromARGB(255, 78, 146, 80),
            ),
            CustomSizebox(
              height: 30.h,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Customtext1(
                  text1: 'Real Life',
                  text2: ' Real Life watch & Sunglass Combo',
                ),
                Text(
                  '(black)',
                  style: TextStyle(fontSize: 16),
                ),
                CustomSizebox(
                  height: 30.h,
                ),
                CustomRating(
                  text1: 'Good',
                  text2: ' 12 Rating',
                ),
                CustomSizebox(
                  height: 10.h,
                ),
                CustomStack(
                  height: 40,
                  width: 80,
                  color: Colors.green,
                  text1: "Saver Deal",
                ),
                CustomSizebox(
                  height: 10.h,
                ),
                Row(
                  children: [
                    Text(
                      "81 % Off 1,599 ",
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 20,
                          color: Color.fromARGB(255, 2, 147, 7)),
                    ),
                    Text(
                      " ₹299",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                Text(
                  'Free delivery by 26th Jul',
                  style: TextStyle(
                    fontSize: 15,
                  ),
                ),
                CustomSizebox(
                  height: 5.h,
                ),
                Divider(
                  height: 5,
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Find seller to deliver',
                        style: TextStyle(
                          fontSize: 16,
                        ),
                      ),
                      OutlinedButton(
                        onPressed: () {
                          showModalBottomSheet(
                            context: context,
                            builder: (context) {
                              return Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Text("Enter Pincode"),
                                    TextFormField(
                                      decoration:
                                          InputDecoration(hintText: "PinCode"),
                                    )
                                  ],
                                ),
                              );
                            },
                          );
                        },
                        child: Text("PinCode"),
                      )
                    ],
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
