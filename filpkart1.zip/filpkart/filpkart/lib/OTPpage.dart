import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

class OtpPage extends StatefulWidget {
  const OtpPage({super.key});

  @override
  State<OtpPage> createState() => _OtpPageState();
}

class _OtpPageState extends State<OtpPage> {
  bool isPhoneNumberValid = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      body: Column(
        children: [
          Container(
            height: 60,
            width: double.infinity,
            decoration: const BoxDecoration(color: Colors.blueAccent),
            child: Row(
              children: [
                const Padding(
                    padding: EdgeInsets.all(8),
                    child: CloseButton(
                      color: Colors.white54,
                    )),
                const SizedBox(
                  width: 20,
                ),
                const Text(
                  "Flipkard",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Colors.white),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(25),
                      topRight: Radius.circular(25))),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 40,
                    ),
                    const Text(
                      "Log In for the best experience",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                    ),
                    const Text(
                      "Enter your phone number to continue",
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    IntlPhoneField(
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Phone Number'),
                      initialCountryCode: 'IN',
                      onChanged: (phone) {
                        setState(() {
                          // Assuming that a complete phone number should have at least 10 digits
                          isPhoneNumberValid = phone.number.length >= 10;
                        });
                      },
                    ),
                    const Spacer(),
                    Center(
                      child: Container(
                          height: 40,
                          width: 300,
                          decoration: BoxDecoration(
                              color: isPhoneNumberValid
                                  ? Colors.blue
                                  : const Color.fromARGB(255, 215, 209, 209)),
                          child: MaterialButton(
                              onPressed: isPhoneNumberValid
                                  ? () {
                                      // Proceed to the next step
                                      // Add your logic here
                                    }
                                  : null,
                              child: const Text(
                                "Continue",
                                style: TextStyle(
                                    fontSize: 16, color: Colors.white),
                              ))),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
